from django.shortcuts import render, redirect
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializer import JobDescriptionSerializer, JobDescription, ResumeSerializer, Resume
from .analyzer import process_resume
from .forms import ResumeForm
import tempfile


def index(request):
    return render(request, "index.html")

def render_analysis(request):
    data = request.session.get('analysis_data', None)
    if not data:
        return redirect('upload-resume')
    
    # Normalize keys for easier template usage
    context = {
        'data': {
            'Candidate_Name': data.get("Candidate Name", "N/A"),
            'Job_Role_Matched': data.get("Job Role Matched", "N/A"),
            'Match_Score': data.get("Match Score", 0),
            'Strengths': data.get("Strengths", []),
            'Weaknesses_or_Missing_Skills': data.get("Weaknesses / Missing Skills", []),
            'Detailed_Evaluation': {
                'Experience_and_Background': data.get("Detailed Evaluation", {}).get("Experience & Background", ""),
                'Technical_Skills_Match': data.get("Detailed Evaluation", {}).get("Technical Skills Match", ""),
                'Projects_and_Achievements': data.get("Detailed Evaluation", {}).get("Projects & Achievements", ""),
                'Additional_Notes': data.get("Detailed Evaluation", {}).get("Additional Notes", ""),
            }
        }
    }
    return render(request, "resume_analysis.html", context)

class JobDescriptionAPI(APIView):
    def get(self, request):
        queryset = JobDescription.objects.all()
        serializer = JobDescriptionSerializer(queryset, many=True)
        return Response({
            'status': True,
            'data': serializer.data
        })
        
class AnalyzeResumeAPI(APIView):
    def post(self, request):
        try:
            data = request.data
            if not data.get('job_description'):
                return Response({
                    'status': False,
                    'message': 'job_description is required',
                    'data': {}
                })
            serializer = ResumeSerializer(data=data)
            if not serializer.is_valid():
                return Response({
                    'status': False,
                    'message': 'errors',
                    'data': serializer.errors
                })
            serializer.save()
            _data = serializer.data
            resume_instance = Resume.objects.get(id=_data['id'])
            resume_path = resume_instance.resume.path
            job_description = JobDescription.objects.get(id=data.get('job_description')).job_description
            analyzed_data = process_resume(resume_path, job_description)
            return Response({
                'status': True,
                'message': 'resume analyzed',
                'data': analyzed_data
            })
        except Exception as e:
            return Response({
                'status': False,
                'message': str(e),
                'data': {}
            })

    def get(self, request):
        return Response({
            'status': False,
            'message': 'Use POST to analyze a resume.',
            'data': {}
        }, status=405)

def index(request):
    return render(request, "index.html")


def upload_resume(request):
    if request.method == 'POST':
        form = ResumeForm(request.POST, request.FILES)
        if form.is_valid():
            job_desc_text = form.cleaned_data['job_description']
            job_desc_obj = JobDescription.objects.create(
                job_title="Uploaded via Form",
                job_description=job_desc_text
            )

            resume_file = request.FILES.get('resume')
            if resume_file:
                resume_obj = Resume.objects.create(
                    resume=resume_file,
                    job_description=job_desc_obj
                )

                # Save the uploaded file to a temp location
                with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp_file:
                    for chunk in resume_file.chunks():
                        temp_file.write(chunk)
                    temp_resume_path = temp_file.name

                analyzed_data = process_resume(temp_resume_path, job_desc_text)
                request.session['analysis_data'] = analyzed_data

                return redirect('resume-analysis')
            
        # If form is invalid or resume is missing
        return render(request, 'upload.html', {'form': form})

    else:
        form = ResumeForm()
        return render(request, 'upload.html', {'form': form})
