import pdfplumber
import spacy
from groq import Groq
import json

def extract_text_from_pdf(pdf_path):
    text = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        print(f"PDF extraction error: {e}")
    if not text.strip():
        print("WARNING: Extracted text is empty from PDF.")
    return text.strip()

API_KEY = "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"

def analyze_resume_with_llm(resume_text: str, job_description: str) -> dict:
    # Filter out meaningless input
    valid_words = [w for w in job_description.split() if w.isalpha() and len(w) > 1]
    if len(valid_words) < 5:
        return {
            "Candidate Name": "N/A",
            "Job Role Matched": "Invalid or Too Short Job Description",
            "Match Score": 0,
            "Strengths": [],
            "Weaknesses / Missing Skills": ["Job description too short or invalid to perform meaningful analysis."],
            "Detailed Evaluation": {
                "Experience & Background": "N/A",
                "Technical Skills Match": "N/A",
                "Projects & Achievements": "N/A",
                "Additional Notes": "N/A"
            }
        }

    full_prompt = f"""You are an intelligent resume screening assistant. Your task is to analyze a candidate's resume in relation to the provided job description and give a detailed evaluation.

Respond in valid JSON format matching the structure described below. Do not return plain text or markdown.

Example format:

{{
  "Candidate Name": "John Doe",
  "Job Role Matched": "React Developer",
  "Match Score": 7,
  "Strengths": [
    "Strong educational background in Computer Science",
    "Experience with React.js and Redux",
    "Familiar with version control tools like Git"
  ],
  "Weaknesses / Missing Skills": [
    "No hands-on experience with REST APIs",
    "Lacks knowledge of state management libraries"
  ],
  "Detailed Evaluation": {{
    "Experience & Background": "The candidate has a degree in Computer Science and has worked on multiple frontend projects...",
    "Technical Skills Match": "Good match with React.js, HTML, and CSS; lacking backend integration experience.",
    "Projects & Achievements": "Built a job portal app and a chat application during internships.",
    "Additional Notes": "Good communication skills and participated in open-source projects."
  }}
}}

Now, I will provide the job description followed by the candidate’s resume. Please analyze accordingly.

### 📝 Job Description:
{job_description}

### 📄 Resume:
{resume_text}
"""

    try:
        client = Groq(api_key=API_KEY)
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{'role': 'user', 'content': full_prompt}],
            temperature=0.7,
            response_format={'type': "json_object"},
        )
        result = response.choices[0].message.content
        return json.loads(result)
    except Exception as e:
        print("Error:", e)
        return {"error": str(e)}




def process_resume(pdf_path, job_description):
    try:
        resume_text = extract_text_from_pdf(pdf_path)
        data = analyze_resume_with_llm(resume_text, job_description)
        print("DEBUG: extracted resume text =>", resume_text[:100])
        print("DEBUG: LLM response =>", data)
        candidate_name = data.get("Candidate Name", "N/A")
        job_role = data.get("Job Role Matched", "N/A")
        match_score = data.get("Match Score", 0)

        # You can include these in the returned data if needed
        data["Candidate Name"] = candidate_name
        data["Job Role Matched"] = job_role
        data["Match Score"] = match_score
        print("DEBUG: Extracted resume text =>", resume_text[:200])
        return data
    except Exception as e:
        print(e)
        return None
