# resumechecker/forms.py
from django import forms
from .models import Resume, JobDescription

class ResumeForm(forms.Form):
    job_description = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control'}))
