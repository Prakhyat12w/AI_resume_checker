from django.contrib import admin
from .models import Resume, JobDescription

admin.site.register(Resume)
admin.site.register(JobDescription)
